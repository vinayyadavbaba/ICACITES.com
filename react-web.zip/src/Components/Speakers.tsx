const Speakers = () => {
  return (
    <div>
      <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="my-8 min-h-[calc(100vh-28.8rem)]">
          <h1 className="text-3xl font-bold text-center mb-10">
            Speakers for ICACITES 2024
          </h1>
          <div className="grid xl:grid-cols-3 md:grid-cols-2 grid-cols-1 gap-x-5 gap-y-8 px-5">
            <div className="col-span-1 shadow-md grid grid-cols-3 gap-3 bg-gray-100 rounded-lg">
              <div className="col-span-1 w-full h-44">
                <img
                  src="/Dr-Avadhesh-Kumar.jpg"
                  className="h-full w-full object-cover rounded-lg "
                  alt="Prof. (Dr.) Sri Niwas Singh"
                />
              </div>
              <div className="flex flex-col gap-1 col-span-2 my-2">
                <div className="py-2">
                  <div className="rounded-full font-semibold w-fit bg-amber-600 bg-opacity-20">
                    <p className="px-2 py-0.5 text-sm text-amber-800">
                      National Speaker
                    </p>
                  </div>
                </div>
                <span className="font-semibold text-lg">
                Dr.Avadhesh Kumar
                </span>
                <span className="font-light text-xs pr-2">
                Pro Vice-Chancellor, Galgotias University India.
                </span>
              </div>
            </div>
            <div className="col-span-1 shadow-md grid grid-cols-3 gap-3 bg-gray-100 rounded-lg">
              <div className="col-span-1 w-full h-44">
                <img
                  src="/Dr-Ing-Justice-Ohene-Akoto.jpg"
                  className="h-full w-full object-cover rounded-lg "
                  alt="Prof. (Dr.) M.N.Doja"
                />
              </div>
              <div className="flex flex-col gap-1 col-span-2 my-2">
                <div className="py-2">
                  <div className="rounded-full font-semibold w-fit bg-amber-600 bg-opacity-20">
                    <p className="px-2 py-0.5 text-sm text-amber-800">
                     International Speaker
                    </p>
                  </div>
                </div>
                <span className="font-semibold text-lg">
                Dr.Ing Justice Ohene Akoto
                </span>
                <span className="font-light text-xs pr-2">
                Board Member, FEL, World Energy Council.
                </span>
              </div>
            </div>
            <div className="col-span-1 shadow-md grid grid-cols-3 gap-3 bg-gray-100 rounded-lg">
              <div className="col-span-1 w-full h-44">
                <img
                  src="/Dr-Khalid-Yahya.jpg"
                  className="h-full w-full object-cover rounded-lg "
                  alt="Prof. (Dr.) S. K. Singh"
                />
              </div>
              <div className="flex flex-col gap-1 col-span-2 my-2">
                <div className="py-2">
                  <div className="rounded-full font-semibold w-fit bg-amber-600 bg-opacity-20">
                    <p className="px-2 py-0.5 text-sm text-amber-800">
                      International Speaker
                    </p>
                  </div>
                </div>
                <span className="font-semibold text-lg">
                Dr. Khalid Yahya
                </span>
                <span className="font-light text-xs pr-2">
                
                Institutional Information: Faculty Of Engineering And Architecture, Electrical And Electronics Engineering Egypt
                </span>
              </div>
            </div>
            <div className="col-span-1 shadow-md grid grid-cols-3 gap-3 bg-gray-100 rounded-lg">
              <div className="col-span-1 w-full h-44">
                <img
                  src="/dr-Prabhakar-tiwari.jpg"
                  className="h-full w-full object-cover rounded-lg "
                  alt="Dr. Akhilesh Tiwari"
                />
              </div>
              <div className="flex flex-col gap-1 col-span-2 my-2">
                <div className="py-2">
                  <div className="rounded-full font-semibold w-fit bg-amber-600 bg-opacity-20">
                    <p className="px-2 py-0.5 text-sm text-amber-800">
                      National Speaker
                    </p>
                  </div>
                </div>
                <span className="font-semibold text-lg">
                Dr. Prabhakar Tiwari
                </span>
                <span className="font-light text-xs pr-2">
                Associate Professor, Electrical Engineering Department, Madan Mohan Malviya University of Technology, Gorakhpur, U.P, India.
                </span>
              </div>
              </div>
            <div className="col-span-1 shadow-md grid grid-cols-3 gap-3 bg-gray-100 rounded-lg">
              <div className="col-span-1 w-full h-44">
                <img
                  src="/Dr-Sivakumar-Kalimuthu.jpg"
                  className="h-full w-full object-cover rounded-lg "
                  alt="Dr. Akhilesh Tiwari"
                />
              </div>
              <div className="flex flex-col gap-1 col-span-2 my-2">
                <div className="py-2">
                  <div className="rounded-full font-semibold w-fit bg-amber-600 bg-opacity-20">
                    <p className="px-2 py-0.5 text-sm text-amber-800">
                      National Speaker
                    </p>
                  </div>
                </div>
                <span className="font-semibold text-lg">
                Dr. Sivakumar Kalimuthu
                </span>
                <span className="font-light text-xs pr-2">
                Senior Lecturer, Faculty of Engineering, Build Environment and Information Technology, SEGi University, Damansara, Kuala Lumpur, Malaysia.
                </span>
              </div>
            </div>
            <div className="col-span-1 shadow-md grid grid-cols-3 gap-3 bg-gray-100 rounded-lg">
              <div className="col-span-1 w-full h-44">
                <img
                  src="/Dr-Ramkumar.jpg"
                  className="h-full w-full object-cover rounded-lg "
                  alt="Dr. Virender Ranga"
                />
              </div>
              <div className="flex flex-col gap-1 col-span-2 my-2">
                <div className="py-2">
                  <div className="rounded-full font-semibold w-fit bg-amber-600 bg-opacity-20">
                    <p className="px-2 py-0.5 text-sm text-amber-800">
                      National Speaker
                    </p>
                  </div>
                </div>
                <span className="font-semibold text-lg">
                Dr. J. Ramkumar
                </span>
                <span className="font-light text-xs pr-2">
                Professor, Department of Mechanical Engineering, IIT Kanpur India.
                </span>
              </div>
            </div>
            <div className="col-span-1 shadow-md grid grid-cols-3 gap-3 bg-gray-100 rounded-lg">
              <div className="col-span-1 w-full h-44">
                <img
                  src="/Dr-S-Albert-Alexander.jpg"
                  className="h-full w-full object-cover rounded-lg "
                  alt="Prof. (Dr.) P. Nagabhushan"
                />
              </div>
              <div className="flex flex-col gap-1 col-span-2 my-2">
                <div className="py-2">
                  <div className="rounded-full font-semibold w-fit bg-amber-600 bg-opacity-20">
                    <p className="px-2 py-0.5 text-sm text-amber-800">
                      National Speaker
                    </p>
                  </div>
                </div>
                <span className="font-semibold text-lg">
                Dr. S. Albert Alexander
                </span>
                <span className="font-light text-xs pr-2">
                Chairman, IEEE Power Electronics Society, IEEE Madras Section  UGC Raman Research Fellow  Associate Professor School of Electrical Engineering Vellore Institute of Technology, Vellore.
                </span>
              </div>
            </div>
            <div className="col-span-1 shadow-md grid grid-cols-3 gap-3 bg-gray-100 rounded-lg">
              <div className="col-span-1 w-full h-44">
                <img
                  src="/Pratapsinh-Kakaso-Desai.jpg"
                  className="h-full w-full object-cover rounded-lg "
                  alt="Prof. (Dr.) Satish K. Singh"
                />
              </div>
              <div className="flex flex-col gap-1 col-span-2 my-2">
                <div className="py-2">
                  <div className="rounded-full font-semibold w-fit bg-amber-600 bg-opacity-20">
                    <p className="px-2 py-0.5 text-sm text-amber-800">
                      National Speaker
                    </p>
                  </div>
                </div>
                <span className="font-semibold text-lg">
                Pratapsinh Kakaso Desai
                </span>
                <span className="font-light text-xs pr-2">
                PRESIDENT, ISTE
                </span>
             
              </div>
            </div>
            <div className="col-span-1 shadow-md grid grid-cols-3 gap-3 bg-gray-100 rounded-lg">
              <div className="col-span-1 w-full h-44">
                <img
                  src="https://res.cloudinary.com/dooi3sikb/image/upload/v1710526985/ConferenceAssets/wzcnjyljg4jigusvcmhx.jpg"
                  className="h-full w-full object-cover rounded-lg "
                  alt="Prof. (Dr.) Asheesh K. Singh"
                />
              </div>
              <div className="flex flex-col gap-1 col-span-2 my-2">
                <div className="py-2">
                  <div className="rounded-full font-semibold w-fit bg-amber-600 bg-opacity-20">
                    <p className="px-2 py-0.5 text-sm text-amber-800">
                      National Speaker
                    </p>
                  </div>
                </div>
                <span className="font-semibold text-lg">
                  Prof. (Dr.) Asheesh K. Singh
                </span>
                <span className="font-light text-xs pr-2">
                EE Department, MNNIT Allahabad.
                </span>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
export default Speakers;
