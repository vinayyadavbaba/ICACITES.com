const OrganizingComittee = () => {
  return (
    <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
      <div className="prose mx-4" itemType="https://schema.org/Organization">
        <h1
          className="heading text-prose-headings font-extrabold text-4xl mb-4 leading-9 border-l-4 border-red-600 pl-4 pr-4"
          itemProp="name"
        >
          ORGANISING COMMITTEE
        </h1>
        <div itemProp="department" className="ml-3">
          <h2
            className="heading text-prose-headings font-extrabold text-2.25xl mb-4 leading-9 border-l-4 border-red-600 pl-4 pr-4"
            itemProp="name"
            id="Chief Patron"
          >
            Chief Patron
          </h2>
          <ul className="mb-5 pl-6.5 list-disc ml-10 marker:text-zinc-500">
            <li
              itemProp="member"
              id="Dr. R. P. Chadha"
              className="pl-1.5 mt-2 mb-2 "
            >
              <span itemProp="name">Dr. R. P. Chadha</span>,{" "}
              <span itemProp="jobTitle">Chairman</span>
            </li>
            <li
              itemProp="member"
              id="Mr. Sohil Chadha"
              className="pl-1.5 mt-2 mb-2"
            >
              <span itemProp="name">Mr. Sohil Chadha</span>,{" "}
              <span itemProp="jobTitle">Vice Chairman</span>
            </li>
          </ul>
        </div>
        <div itemProp="department" className="ml-3">
          <h2
            className="heading text-prose-headings font-extrabold text-2.25xl mb-4 leading-9 border-l-4 border-red-600 pl-4 pr-4"
            itemProp="name"
            id="Patrons"
          >
            Patrons
          </h2>
          <ul className="mb-5 pl-6.5 list-disc ml-10 marker:text-zinc-500">
            <li
              itemProp="member"
              className="pl-1.5 mt-2 mb-2"
              id="Shri B. K. Arora, Secretary, ITSEC"
            >
              <span itemProp="name">Shri B. K. Arora</span>,{" "}
              <span itemProp="jobTitle">Secretary, ITSEC</span>
            </li>
          </ul>
        </div>
        <div itemProp="department" className="ml-3">
          <h2
            className="heading text-prose-headings font-extrabold text-2.25xl mb-4 leading-9 border-l-4 border-red-600 pl-4 pr-4"
            itemProp="name"
            id="Conference General Chair"
          >
            Conference General Chair
          </h2>
          <ul className="mb-5 pl-6.5 list-disc ml-10 marker:text-zinc-500">
            <li itemProp="member" id="Prof. (Dr.) Mayank Garg">
              <span itemProp="name">Prof. (Dr.) Mayank Garg</span>,{" "}
              <span itemProp="jobTitle">Director, ITSEC</span>
            </li>
            <li itemProp="member" id="Prof. (Dr.) S. K. Singh">
              <span itemProp="name">Prof. (Dr.) Vishnu Sharma,</span>,{" "}
              <span itemProp="jobTitle"> Dean, CSE, ITSEC</span>
            </li>
          </ul>
        </div>
        <div itemProp="department" className="ml-3">
          <h2
            className="heading text-prose-headings font-extrabold text-2.25xl mb-4 leading-9 border-l-4 border-red-600 pl-4 pr-4"
            itemProp="name"
            id="Convener &amp; Conference Organising Chair"
          >
             Organising Chair
          </h2>
          <ul className="mb-5 pl-6.5 list-disc ml-10 marker:text-zinc-500">
            <li itemProp="member" id="Prof. (Dr.) Vishnu Sharma">
              <span itemProp="name">Mr. Navneet Kumar</span>,{" "}
              <span itemProp="jobTitle">ECE , ITSEC</span>
            </li>
          </ul>
        </div>
        <div itemProp="department" className="ml-3">
          <h2
            className="heading text-prose-headings font-extrabold text-2.25xl mb-4 leading-9 border-l-4 border-red-600 pl-4 pr-4"
            itemProp="name"
            id="Conference Chair"
          >
               Convener 
          </h2>
          <ul className="mb-5 pl-6.5 list-disc ml-10 marker:text-zinc-500">
            <li itemProp="member" id="Prof. (Dr.) Vishnu Sharma">
              <span itemProp="name">Mr.Agha Asim Husain</span>,{" "}
              <span itemProp="jobTitle"> ECE , ITSEC</span>
            </li>
            <li itemProp="member" id="Prof. (Dr.) Vishnu Sharma">
              <span itemProp="name">Mr.Prabhakar Sharma</span>,{" "}
              <span itemProp="jobTitle"> ECE , ITSEC</span>
            </li>
          </ul>
        </div>
        <div itemProp="department" className="ml-3">
          <h2
            className="heading text-prose-headings font-extrabold text-2.25xl mb-4 leading-9 border-l-4 border-red-600 pl-4 pr-4"
            itemProp="name"
            id="Conference Chair"
          >
            Conference Chair
          </h2>
          <ul className="mb-5 pl-6.5 list-disc ml-10 marker:text-zinc-500">
            <li itemProp="member" id="Dr.A Ambikapathy">
              <span itemProp="name">Dr.A Ambikapathy</span>,{" "}
              <span itemProp="jobTitle">H.O.D, ECE, ITSEC</span>
            </li>
            <li itemProp="member" id="Dr. Setu Garg">
              <span itemProp="name">Dr.Setu Garg</span>,{" "}
              <span itemProp="jobTitle">ECE, ITSEC</span>
            </li>
          </ul>
        </div>
        <div itemProp="department" className="ml-3">
          <h2
            className="heading text-prose-headings font-extrabold text-2.25xl mb-4 leading-9 border-l-4 border-red-600 pl-4 pr-4"
            itemProp="name"
            id="Conference Publication Chair"
          >
            Conference Publication Chair
          </h2>
          <ul className="mb-5 pl-6.5 list-disc ml-10 marker:text-zinc-500">
            <li itemProp="member" id="Prof. (Dr.) Jaya Sinha">
              <span itemProp="name">Mr.Shahid Khan</span>,
              <span itemProp="jobTitle"> ECE, ITSEC</span>
            </li>
            <li itemProp="member" id="Prof.(Dr.) Hariom Tyagi">
              <span itemProp="name">Ms.Pragati Tripathi</span>,
              <span itemProp="jobTitle"> ECE, ITSEC</span>
            </li>    
          </ul>
        </div>     
        
        <div itemProp="department" className="ml-3">
          <h2
            className="heading text-prose-headings font-extrabold text-2.25xl mb-4 leading-9 border-l-4 border-red-600 pl-4 pr-4"
            itemProp="name"
            id="Technical Program Chairs"
          >
            Technical Program Chairs
          </h2>
          <ul className="mb-5 pl-6.5 list-disc ml-10 marker:text-zinc-500">
            <li itemProp="member" id="Prof. (Dr.) Ashish Gupta">
              <span itemProp="name">Dr. Upender Agarwal </span>,{" "}
              <span itemProp="jobTitle"> AP,EEE, ITSEC</span>
            </li>
            <li itemProp="member" id="Prof. (Dr.) Nitin Mishra">
              <span itemProp="name">Dr. Praveen Bhola</span>,{" "}
              <span itemProp="jobTitle">AP,EEE , ITSEC</span>
            </li>
            <li itemProp="member" id="Prof. (Dr.) Kuldeep Malik">
              <span itemProp="name">Dr. Rajiv Ranjan</span>,{" "}
              <span itemProp="jobTitle">AP,EEE , ITSEC</span>
            </li>
            {/**<li itemProp="member" id="Prof. (Dr.) Sachi Gupta">
              <span itemProp="name">Prof. (Dr.) Sachi Gupta</span>,{" "}
              <span itemProp="jobTitle">CSE, GCET</span>
            </li>
            <li itemProp="member" id="Prof. (Dr.) Arun Kumar">
              <span itemProp="name">Prof. (Dr.) Arun Kumar</span>,{" "}
              <span itemProp="jobTitle">CSE, GCET</span>
            </li> */}
          </ul>
        </div>
        <div itemProp="department" className="ml-3">
          <h2
            className="heading text-prose-headings font-extrabold text-2.25xl mb-4 leading-9 border-l-4 border-red-600 pl-4 pr-4"
            itemProp="name"
            id="Organizing Committee"
          >
            Organizing Committee
          </h2>
          <ul className="mb-5 pl-6.5 list-disc ml-10 marker:text-zinc-500">
            <li itemProp="member" id="Prof. (Dr.) Vrinda Sachdeva">
              <span itemProp="name">Dr. Setu Garg</span>,{" "}
              <span itemProp="jobTitle">ECE, ITSEC</span>
            </li>
            <li itemProp="member" id="Prof. Tarun Chug">
              <span itemProp="name">Mr. Agha Asim Husain</span>,{" "}
              <span itemProp="jobTitle">ECE, ITSEC</span>
            </li>
            <li itemProp="member" id="Prof. Abhishek Shivhare">
              <span itemProp="name">Mr. Prabhakar Sharma</span>,{" "}
              <span itemProp="jobTitle">ECE, ITSEC</span>
            </li>
            <li itemProp="member" id="Prof. Yogesh Sharma">
              <span itemProp="name">Mr. Navneet Kumar</span>,{" "}
              <span itemProp="jobTitle">ECE, ITSEC</span>
            </li>
            <li itemProp="member" id="Prof. Prachi Jain">
              <span itemProp="name">Ms. Manju Singh</span>,{" "}
              <span itemProp="jobTitle">ECE, ITSEC</span>
            </li>
            <li itemProp="member" id="Prof. Akansha Sharma">
              <span itemProp="name">Mr. Shahid Khan</span>,{" "}
              <span itemProp="jobTitle">ECE, ITSEC</span>
            </li>
            <li itemProp="member" id="Prof. Akansha Sharma">
              <span itemProp="name">Ms.Pragati Tripathi</span>,{" "}
              <span itemProp="jobTitle">ECE, ITSEC</span>
              </li>
              <li itemProp="member" id="Prof. Akansha Sharma">
              <span itemProp="name">Mr.Praveen Bhoola</span>,{" "}
              <span itemProp="jobTitle">EEE, ITSEC</span>
              </li>
              <li itemProp="member" id="Prof. Akansha Sharma">
              <span itemProp="name">Mr.Upendra Agrawal</span>,{" "}
              <span itemProp="jobTitle">EEE, ITSEC</span>
              </li>
              <li itemProp="member" id="Prof. Akansha Sharma">
              <span itemProp="name">Mr.Rajeev Ranjan</span>,{" "}
              <span itemProp="jobTitle">EEE, ITSEC</span>
              </li>
          </ul>
        </div>
        <div itemProp="department" className="ml-3">
          <h2
            className="heading text-prose-headings font-extrabold text-2.25xl mb-4 leading-9 border-l-4 border-red-600 pl-4 pr-4"
            itemProp="name"
            id="Publication Committee"
          >
            Finance Committee
          </h2>
          <ul className="mb-5 pl-6.5 list-disc ml-10 marker:text-zinc-500">
            <li itemProp="member" id="Prof. Abhishek Shivhare">
              <span itemProp="name">Dr.Prabhakar Sharma</span>,{" "}
              <span itemProp="jobTitle">ECE, ITSEC</span>
            </li>
            <li itemProp="member" id="Prof. Yogesh Sharma, CSE, ITSEC">
              <span itemProp="name">Prof.(Dr.)Setu Garg</span>,{" "}
              <span itemProp="jobTitle">ECE, ITSEC</span>
            </li>
          </ul>
        </div>
        <div itemProp="department" className="ml-3">
          <h2
            className="heading text-prose-headings font-extrabold text-2.25xl mb-4 leading-9 border-l-4 border-red-600 pl-4 pr-4"
            itemProp="name"
            id="Hospitality Committee"
          >
          
            Website Committee
          </h2>
          <ul className="mb-5 pl-6.5 list-disc ml-10 marker:text-zinc-500">
            <li itemProp="member" id="Prof. Prachi Jain">
              <span itemProp="name">Mr.Abhishek Patel</span>,{" "}
              <span itemProp="jobTitle"> ECE, Student ,ITSEC</span>
            </li>
            <li itemProp="member" id="Prof. Monika">
              <span itemProp="name">Mr.Sanjeev Yadav</span>,{" "}
              <span itemProp="jobTitle"> ECE, Student ,ITSEC</span>
            </li>
            <li itemProp="member" id="Mr. Sandeep Yadav">
              <span itemProp="name">Mr.Piyush Kumar</span>,{" "}
              <span itemProp="jobTitle">ECE, Student ,ITSEC</span>
            </li>
           
          </ul>
        </div>
        <div itemProp="department" className="ml-3">
          <h2
            className="heading text-prose-headings font-extrabold text-2.25xl mb-4 leading-9 border-l-4 border-red-600 pl-4 pr-4"
            itemProp="name"
            id="Sponsorship/Media Committee"
          >
            Sponsorship/Media Committee
          </h2>
          <ul className="mb-5 pl-6.5 list-disc ml-10 marker:text-zinc-500">
            
            <li itemProp="member" id="Prof. Ghanshyam Yadav">
              <span itemProp="name">Ms. Pragati Tripathi</span>,{" "}
              <span itemProp="jobTitle">ECE, ITSEC</span>
            </li>
            <li itemProp="member" id="Prof. (Dr.) Arun Kumar">
              <span itemProp="name">Mr. Shahid Khan</span>,{" "}
              <span itemProp="jobTitle">ECE, ITSEC</span>
            </li>
            <li className="list-none">
              <h3 className="heading" itemProp="name">
                Student Co-Ordinators
              </h3>
              <ul>
                <li itemProp="member" id="Mr. Abhishek Patel">
                  <span itemProp="name">Mr. ABHISHEK PATEL</span>,{" "}
                  <span itemProp="jobTitle">ECE Student, ITSEC</span>
                </li>
                <li itemProp="member" id="Mr. Piyush Kumar">
                  <span itemProp="name">Mr. PIYUSH KUMAR</span>,{" "}
                  <span itemProp="jobTitle">ECE Student, ITSEC</span>
                </li>
                <li itemProp="member" id="Mr. Sanjeev Yadav">
                  <span itemProp="name">Mr. SANJEEV YADAV</span>,{" "}
                  <span itemProp="jobTitle">ECE Student, ITSEC</span>
                </li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};
export default OrganizingComittee;
