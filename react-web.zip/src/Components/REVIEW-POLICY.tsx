const REVIEW_POLICY = () => {
  const height200px = {
    height:300
  };

  return (
    <div>
      <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="prose mx-4 my-8 w-[700px]">
          <h1 className="heading text-tw-prose-headings font-extrabold text-2xl mt-0 mb-2 leading-tight border-l-4 border-red-600 pl-4 pr-4">
          REVIEW POLICY
          </h1>
          <br>
          </br>
          <div>
            <a
              href="/REVIEW_POLICY.pdf" target="_blank"
              className="inline-flex items-center justify-center px-5 py-2 mr-3 text-base font-medium text-center text-white rounded-lg bg-red-700 hover:bg-red-800 focus:ring-4 focus:ring-red-300 no-underline dark:focus:ring-red-900"
            >
              {" "}
              Download PDF
            </a>
          </div>
          <div style={height200px}>
         
          </div>
          
        </div>
      </div>
    </div>
  );
};
export default REVIEW_POLICY;
