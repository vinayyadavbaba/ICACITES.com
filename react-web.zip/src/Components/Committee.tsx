const Committee = () => {
  return (
    <div>
      <h1 className="my-40 mx-40 text-4xl font-extrabold">
        Committee Coming soon....
      </h1>
    </div>
  );
};

export default Committee;
