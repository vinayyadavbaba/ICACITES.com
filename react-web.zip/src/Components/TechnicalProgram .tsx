const TechnicalProgram = () => {
  return (
    <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
      <div className="prose mx-4">
        <h1 className="heading text-prose-headings font-extrabold text-3xl mb-3 leading-9 border-l-4 border-red-600 pl-4 pr-4">
          Technical Program Committee
        </h1>
        <div>
          <ul className="list-disc mt-5 mb-5 pl-6.5 m-10 marker:text-zinc-500">
           
            <li className="pl-1.5 mt-2 mb-2">
            Prof. (Dr.) RamaniKanan	 , Teknologi PETRONAS, Malaysia.
            </li>
            <li className="pl-1.5 mt-2 mb-2">
            Prof. Ohene-Akoto, Justice.	Kwame Nkrumah University of Science and Technology (KNUST), Ghana, West Africa.
            </li>
            <li className="pl-1.5 mt-2 mb-2">
            Prof. (Dr.) Meenakshi Rawat	, IIT Roorkee, India.
            </li>
            <li className="pl-1.5 mt-2 mb-2">
            Dr.Pramod Kumar Tiwari	, IIT Patna, India.
            </li>
            <li className="pl-1.5 mt-2 mb-2">
            Prof. (Dr.) Garima Srivastava	, JNU, Delhi, India.
            </li>
            <li className="pl-1.5 mt-2 mb-2">
            Mr. Mokhtar Shouran ,	Wolfson Centre for Magnetics Cardiff University
Cardiff, United Kingdom
            </li>
            <li className="pl-1.5 mt-2 mb-2">
            Prof. (Dr.) R A Mishra ,	MNNIT, Prayagraj, India.
            </li>
            <li className="pl-1.5 mt-2 mb-2">Dr. Amarjit Kumar ,	NIT, Warangal, India.</li>
            <li className="pl-1.5 mt-2 mb-2">Dr. Vinay Kumar	, MNNIT, Prayagraj, India.</li>
            <li className="pl-1.5 mt-2 mb-2">Prof. (Dr.) Neeraj Pratap Singh ,	NIT, Kurukshetra, India.</li>
            <li className="pl-1.5 mt-2 mb-2">Dr. Arvind Sharma ,	NIT, Kurukshetra, India.</li>
            <li className="pl-1.5 mt-2 mb-2">Prof. (Dr.) Manoj Kumar Shukla	, HBTU, Kanpur, India.</li>
            <li className="pl-1.5 mt-2 mb-2">Prof. (Dr.) Harsh Vikram Singh ,	KNIT, Sultanpur, India</li>
            <li className="pl-1.5 mt-2 mb-2">Prof. (Dr.) Gajendra Singh	, ABES Engg College, Ghaziabad, India.</li>
            <li className="pl-1.5 mt-2 mb-2">Prof. (Dr.) Gaurav Upadhaya	, Institute of Technology, Gopeshwar, India.</li>
            <li className="pl-1.5 mt-2 mb-2">Prof. (Dr.) Baibaswata Mohapatra ,	Galgotias University, Greater Noida, India.</li>
            <li className="pl-1.5 mt-2 mb-2">Dr. SandhyaTarar ,	Gautam Buddha University, Noida, India.</li>
            <li className="pl-1.5 mt-2 mb-2">Dr. Jay Singh ,	GL Bajaj ITM, Greater Noida, India.</li>
            <li className="pl-1.5 mt-2 mb-2">Dr. Akash Kumar Bhoi ,	Sikkim Manipal Institute of Technology, Sikkim Manipal University, India.</li>
            <li className="pl-1.5 mt-2 mb-2">Dr. Amit Agrawal ,	ABES Engg College, Ghaziabad, India.</li>
            <li className="pl-1.5 mt-2 mb-2">Prof.( Dr.) Indrasen Singh	G. H. Raisoni College of Engineering, Nagpur, India.</li>
            <li className="pl-1.5 mt-2 mb-2">Dr. Vikas Singh Badhoriaya ,	ABES Engg College, Ghaziabad,UP, India.</li>
            <li className="pl-1.5 mt-2 mb-2">Dharmasa Pawar	, National University of Science  & Technology, Oman.</li>
            <li className="pl-1.5 mt-2 mb-2">Dr. Nagraj H P ,	CIT College, Karnataka, India.</li>
            <li className="pl-1.5 mt-2 mb-2">Prof. Pramod Singh ,	MIET, Meerut, India.</li>
            <li className="pl-1.5 mt-2 mb-2">Prof. (Dr.) Shashwat Pathak	, MIET, Meerut, India.</li>
            <li className="pl-1.5 mt-2 mb-2">Prof. (Dr.) Arvind Kumar Pandey	, MIET, Meerut, India.</li>
            <li className="pl-1.5 mt-2 mb-2">Prof. (Dr.) Ashish Srivastava,	Manipal University, Jaipur, India.</li>
            <li className="pl-1.5 mt-2 mb-2">rof. (Dr.) VanyaArun , IILM College Of Engineering & Technology, Greater Noida, India.</li>
            <li className="pl-1.5 mt-2 mb-2">
            Dr KANTA PRASAD SHARMA	, CHANDIGARH UNIVERSITY INDIA
            </li>
            <li className="pl-1.5 mt-2 mb-2">
            Dr S.M. NANDHAGOPAL,	ASSOCIATE PROFESSOR, DEPARTMENT OF COMPUTER SCIENCE AND ENGINEERING, CHITKARA UNIVERSITY, kalujhinda, Distt, Baddi, 174103, Himachal Pradesh.
            </li>
            <li className="pl-1.5 mt-2 mb-2">
            Dr. M.Sathya ,	Associate Professor and head, Information Science and Engineering, AMC Engineering College, Bangalore, Karnataka.
            </li>
            <li className="pl-1.5 mt-2 mb-2">
            Dr.V.Seedha Devi	, Associate Professor, Department of Information Technology, Jaya Engineering College Thiruninravur, Chennai. Tamil Nadu.
            </li>
            <li className="pl-1.5 mt-2 mb-2">
            Dr. Arvind Kumar ,	National Institute of Technology, Kurukshetra
            </li>
            <li className="pl-1.5 mt-2 mb-2">
            Ms. Richa Gupta ,	Amity University, Dubai.
            </li>
            <li className="pl-1.5 mt-2 mb-2">
            Ahmed Muayad Younus	, Limkokwing University, Malaysia.
            </li>
            <li className="pl-1.5 mt-2 mb-2">
            Dr. Dhiraj Srivastava	, Gov. of India, Ministry of Power, Central Electricity Authority, New Delhi. 
            </li>
            <li className="pl-1.5 mt-2 mb-2">
            Dr.Manoj K. Shukla , Rajkiya Engineering College, Kannauj, U.P.
            </li>
            <li className="pl-1.5 mt-2 mb-2">
            Prof. (Dr.) SudiptoSarkar ,	NSHM School of Engineering & Technology, Durgapur, India.
            </li>
            <li className="pl-1.5 mt-2 mb-2">
            Prof. (Dr.) Satyendra Sharma ,	GL Bajaj ITM Greater Noida, India 
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default TechnicalProgram;
