// Import Swiper React components
import { Swiper, SwiperSlide } from "swiper/react";
import { Link } from "react-router-dom";

// Import Swiper styles
import "swiper/css";
import "swiper/css/pagination";

// import required modules
import { Autoplay, Pagination, Navigation } from "swiper/modules";
const FooterSpeaker = () => {
  return (
    <div className="select-none">
      <div className="flex flex-row items-center mx-5 md:mx-auto">
        <h1 className="text-2xl text-black font-extrabold my-5">
          Hon'ble Speakers
        </h1>
      </div>
      <div className="w-full bg-gray-100 p-4 rounded-lg">
        <div className="swiper mySwiper mx-auto">
          <Swiper
            slidesPerView={1}
            spaceBetween={10}
            autoplay={{
              delay: 1500,
              disableOnInteraction: false,
            }}
            breakpoints={{
              640: {
                slidesPerView: 2,
                spaceBetween: 20,
              },
              768: {
                slidesPerView: 4,
                spaceBetween: 40,
              },
              1024: {
                slidesPerView: 5,
                spaceBetween: 50,
              },
            }}
            modules={[Autoplay, Pagination, Navigation]}
            className="mySwiper"
          >
            <SwiperSlide>
              <div className="col-span-1 flex flex-col items-center">
                <img
                  src="/Dr-Avadhesh-Kumar.jpg"
                  alt="Speaker&#x27;s Photo"
                  className="h-56 border-2 border-gray-300 w-64 object-cover mb-5 rounded-lg shadow-md"
                />
                <div className="rounded-full my-2 bg-amber-600 bg-opacity-20">
                  <p className="px-2 py-0.5 text-sm text-amber-800">
                    National Speaker
                  </p>
                </div>
                <span className="font-bold text-sm text-center">
                Dr. Avadhesh Kumar
                </span>
                <span className="font-light text-xs text-center">
                Pro Vice-Chancellor, Galgotias University India.
                </span>
              </div>
            </SwiperSlide>
            <SwiperSlide>
              <div className="col-span-1 flex flex-col items-center">
                <img
                  src="/Dr-Ing-Justice-Ohene-Akoto.jpg"
                  alt="Speaker&#x27;s Photo"
                  className="h-56 border-2 border-gray-300 w-64 object-cover mb-5 rounded-lg shadow-md"
                />
                <div className="rounded-full my-2 bg-amber-600 bg-opacity-20">
                  <p className="px-2 py-0.5 text-sm text-amber-800">
                    International Speaker
                  </p>
                </div>
                <span className="font-bold text-sm text-center">
                Dr. Ing Justice Ohene Akoto
                </span>
                <span className="font-light text-xs text-center">
                Senior Advisor, JP Partners & Associates, Board Member, Future Energy Leaders, World Energy Council
                </span>
              </div>
            </SwiperSlide>
            <SwiperSlide>
              <div className="col-span-1 flex flex-col items-center">
                <img
                  src="/Dr-Khalid-Yahya.jpg"
                  alt="Speaker&#x27;s Photo"
                  className="h-56 border-2 border-gray-300 w-64 object-cover mb-5 rounded-lg shadow-md"
                />
                <div className="rounded-full my-2 bg-amber-600 bg-opacity-20">
                  <p className="px-2 py-0.5 text-sm text-amber-800">
                    International Speaker
                  </p>
                </div>
                <span className="font-bold text-sm text-center">
                Dr. Khalid Yahya
                </span>
                <span className="font-light text-xs text-center">
                Nisantasi University, Istanbul ,Turkey
                </span>
              </div>
            </SwiperSlide>
            <SwiperSlide>
              <div className="col-span-1 flex flex-col items-center">
                <img
                  src="/dr-Prabhakar-tiwari.jpg"
                  alt="Speaker&#x27;s Photo"
                  className="h-56 border-2 border-gray-300 w-64 object-cover mb-5 rounded-lg shadow-md"
                />
                <div className="rounded-full my-2 bg-amber-600 bg-opacity-20">
                  <p className="px-2 py-0.5 text-sm text-amber-800">
                    National Speaker
                  </p>
                </div>
                <span className="font-bold text-sm text-center">
                Dr. Prabhakar Tiwari
                </span>
                <span className="font-light text-xs text-center">
                Associate Professor, Electrical Engineering Department,
                 Madan Mohan Malviya University of Technology, Gorakhpur, U.P, India.
                </span>
              </div>
            </SwiperSlide>
            <SwiperSlide>
              <div className="col-span-1 flex flex-col items-center">
                <img
                  src="/Dr-Sivakumar-Kalimuthu.jpg"
                  alt="Speaker&#x27;s Photo"
                  className="h-56 border-2 border-gray-300 w-64 object-cover mb-5 rounded-lg shadow-md"
                />
                <div className="rounded-full my-2 bg-amber-600 bg-opacity-20">
                  <p className="px-2 py-0.5 text-sm text-amber-800">
                    National Speaker
                  </p>
                </div>
                <span className="font-bold text-sm text-center">
                Dr. Sivakumar Kalimuthu
                </span>
                <span className="font-light text-xs text-center">
                Senior Lecturer, Faculty of Engineering, Build Environment and Information Technology, SEGi University, Damansara, Kuala Lumpur, Malaysia.
                </span>
              </div>
            </SwiperSlide>
            <SwiperSlide>
              <div className="col-span-1 flex flex-col items-center">
                <img
                  src="/Dr-Ramkumar.jpg"
                  alt="Speaker&#x27;s Photo"
                  className="h-56 border-2 border-gray-300 w-64 object-cover mb-5 rounded-lg shadow-md"
                />
                <div className="rounded-full my-2 bg-amber-600 bg-opacity-20">
                  <p className="px-2 py-0.5 text-sm text-amber-800">
                    National Speaker
                  </p>
                </div>
                <span className="font-bold text-sm text-center">
                Dr. J. Ramkumar
                </span>
                <span className="font-light text-xs text-center">
                Professor, Department of Mechanical Engineering, IIT Kanpur India.
                </span>
              </div>
            </SwiperSlide>
            <SwiperSlide>
              <div className="col-span-1 flex flex-col items-center">
                <img
                  src="/Dr-S-Albert-Alexander.jpg"
                  alt="Speaker&#x27;s Photo"
                  className="h-56 border-2 border-gray-300 w-64 object-cover mb-5 rounded-lg shadow-md"
                />
                <div className="rounded-full my-2 bg-blue-800 bg-opacity-20">
                  <p className="px-2 py-0.5 text-sm text-blue-800">
                    National Speaker
                  </p>
                </div>
                <span className="font-bold text-sm text-center">
                Dr. S Albert Alexander
                </span>
                <span className="font-light text-xs text-center">
                Chairman, IEEE Power Electronics Society, IEEE Madras Section  UGC Raman Research Fellow
                  Associate Professor School of Electrical Engineering Vellore Institute of Technology, Vellore.
                </span>
              </div>
            </SwiperSlide>
            <SwiperSlide>
              <div className="col-span-1 flex flex-col items-center">
                <img
                  src="/Pratapsinh-Kakaso-Desai.jpg"
                  alt="Speaker&#x27;s Photo"
                  className="h-56 border-2 border-gray-300 w-64 object-cover mb-5 rounded-lg shadow-md"
                />
                <div className="rounded-full my-2 bg-blue-800 bg-opacity-20">
                  <p className="px-2 py-0.5 text-sm text-blue-800">
                    National Speaker
                  </p>
                </div>
                <span className="font-bold text-sm text-center">
                Pratapsinh Kakaso Desai
                </span>
                <span className="font-light text-xs text-center">
                PRESIDENT, ISTE
                </span>
             
              </div>
            </SwiperSlide>
          </Swiper>
        </div>
      </div>

      <div className="col-span-1 flex flex-col items-center gap-2 justify-center my-5">
        <div className="inline-flex items-center justify-center px-5 py-2 mr-3 text-base font-medium text-center text-white rounded-lg bg-sky-600 hover:bg-sky-700 shrink-on-hover focus:ring-4 focus:ring-sky-300 no-underline dark:focus:ring-sky-700">
          <Link to={"/speakers"}>View all</Link>
        </div>
      </div>
    </div>
  );
};

export default FooterSpeaker;
