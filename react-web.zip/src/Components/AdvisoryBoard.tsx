const AdvisoryBoard = () => {
  return (
    <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
      <div className="prose mx-4">
        <h1 className="heading  text-prose-headings font-extrabold text-3xl mb-3 leading-tight pl-4 border-l-4 border-red-600  pr-4 text-inherit font-inherit">
          Advisory Board
        </h1>
        <div>
          <ul className="list-disc marker:text-zinc-500 mt-5 mb-5 pl-7 m-3 ">
            <li className="pl-1.5 mt-2 mb-2">Prof. (Dr.) Pardeep Kumar ,	Pro - Vice Chancellor, Manav Bachna International, Institute of Research and Studies, Sector 43, Delhi Surajkund Road, Aravalli Hills, Faridabad. Harvana, INDIA </li>
           <li className="pl-1.5 mt-2 mb-2">Dr Badrul Hisham Ahmad	, Universiti Teknikal Malaysia Melaka, Malaysia.</li>
           <li className="pl-1.5 mt-2 mb-2">Mr. Mokhtar Shouran ,	Wolfson Centre for Magnetics Cardiff University
Cardiff, United Kingdom </li>
           <li className="pl-1.5 mt-2 mb-2">Prof. (Dr.) Badrul Hisham Bin Ahmad ,	Universiti Teknikal, Malaysia</li>
           <li className="pl-1.5 mt-2 mb-2">Dr. Bdereddin Abdul Samad	, Electrical and Electronic Department, Azahra Higher Institution of Sciences and Technology, Azahra, Libya</li>
           <li className="pl-1.5 mt-2 mb-2">Ing. Justice Ohene-Akoto	, Board Member, FEL, World Energy Council</li>
           <li className="pl-1.5 mt-2 mb-2">Dr. Mokhtar Shouran	, Libyan Centre for Engineering Research and Information Technonlgy, Bani Walid, Libya.</li>
           <li className="pl-1.5 mt-2 mb-2">Dr Sivakumar Kalimuthu,	Senior Lecturer, Faculty of Engineering, Build Environment and Information Technology, SEGi University, Damansara, Kuala Lumpur, Malaysia</li>
           <li className="pl-1.5 mt-2 mb-2">Asst. Prof. Khalid YAHYA ,	Institutional Information: Faculty Of Engineering And Architecture, Electrical And Electronics Engineering Egypt</li>
           <li className="pl-1.5 mt-2 mb-2">Prof. Shabana Mehfuz	, Jamia Millia Islamia,New Delhi</li>
           <li className="pl-1.5 mt-2 mb-2">Dr. Ayoub Khan	, College of Computers and Information Technology, 
University of Bisha, Bisha, Saudi Arabia</li>
           <li className="pl-1.5 mt-2 mb-2">Prof. (Dr.).Ahmad Elngar	, Beni-Suef University, Egypt.</li>
           <li className="pl-1.5 mt-2 mb-2">D. K. Lobiyal  ,	JNU, New Delhi</li>
           <li className="pl-1.5 mt-2 mb-2">Dr. Vinay Kumar	, MNIT, Jaipur</li>
           <li className="pl-1.5 mt-2 mb-2"> Dr.Rajendra Sahu	, IIITM,Gwalior</li>
           <li className="pl-1.5 mt-2 mb-2">Ms. Ezhilarasi ,	ISRO, Trivandram, India.</li>
           <li className="pl-1.5 mt-2 mb-2">Dr. Rajeev Sharma	DST, New Delhi, India.</li>
           <li className="pl-1.5 mt-2 mb-2"> Dr.Daniel Okunbor	, Fayetteville State University,  North Carolina.</li>
           <li className="pl-1.5 mt-2 mb-2">Dr. Y. K. Mishra ,	K.N.I.T. Sultanpur, India</li>
           <li className="pl-1.5 mt-2 mb-2">Dr. Sunil Kumar Khatri	, Amity University, Tashkent</li>
           <li className="pl-1.5 mt-2 mb-2">Ravi Bhushan Mishra,
National Institute of Technology, Patna </li>
           <li className="pl-1.5 mt-2 mb-2">Dr. Ahmed T. AlTaani	,Yarmouk University, Jordan</li>
           <li className="pl-1.5 mt-2 mb-2">Dr. Syed Afzal Murtaza Rizvi 	, Jamia Millia Islamia, New Delhi</li>
           <li className="pl-1.5 mt-2 mb-2">Prof. Ohene-Akoto, Justice.	Kwame Nkrumah University of Science and Technology (KNUST), Ghana, West Africa.</li>
           <li className="pl-1.5 mt-2 mb-2">Dr. Siti Nuurul Huda Binti Mohammad Azmin	, University of Malyasia Kelabtab, Jeli</li>
           <li className="pl-1.5 mt-2 mb-2">Dr. Syed Hamid Hassan	, King Abdulaziz University,Jeddah, Saudi Arbia</li>
           <li className="pl-1.5 mt-2 mb-2">Dr. Mario Jose Divan	, National University of La Pampa, Argentina </li>
           <li className="pl-1.5 mt-2 mb-2">Dr. Marcelo Martin Marciszack ,	National Technological University Cordoba,Argentina</li>
           <li className="pl-1.5 mt-2 mb-2">Dr.Adin Will	, Director National Technological University, Argentina </li>
           <li className="pl-1.5 mt-2 mb-2">Dr. Abhinit Anand	Chitkara University, India</li>
           <li className="pl-1.5 mt-2 mb-2">Dr. Afaq Ahmad	, Sultan Qaboos University,Oman </li>
           <li className="pl-1.5 mt-2 mb-2">Dr. H.G.Muazu	, Modibbo Adama University Technology, Nigeria</li>
           <li className="pl-1.5 mt-2 mb-2">Dr. Abubakkar Mohammed ,	Modibbo Adama University Technology, Nigeria</li>
           <li className="pl-1.5 mt-2 mb-2">Dr. Syed Akhter Hossain ,	Daffodil University, Bangladesh</li>
           <li className="pl-1.5 mt-2 mb-2">Dr.A.K.Jain ,	galgotais University, India</li>
           <li className="pl-1.5 mt-2 mb-2">Dr. Parma Nand	, Sharda University, India</li>
           <li className="pl-1.5 mt-2 mb-2">Dr. Ajay Rana	, Amity University, Amity, India </li>
           <li className="pl-1.5 mt-2 mb-2">Dr. Ajay Kumar ,	Chitkara University, India</li>
          </ul>
        </div>
      </div>
    </div>
  );
};
export default AdvisoryBoard;
