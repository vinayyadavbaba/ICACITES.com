const About = () => {
  return (
    <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
      <div>
        <div className="prose max-w-screen-lg mx-4">
          <h1 className="heading border-l-4 border-red-600 pl-4 pr-4 text-tw-prose-headings font-extrabold text-2xl mb-4 leading-tight">
            About ITS Group of Institute
          </h1>
          <p className="text-justify mb-5 mt-5">
            ITS - The Education Group, with its diversified presence across
            industries - including education, hospitality, medical, pharmacy,
            health care, wellness, legal, philanthropy and CSR - has been in a
            business leadership position for many decades. The company has
            undergone tremendous growth and has scaled up its operations in a
            big way over many years, in line with its global ambitions.
          </p>
          <img src="/ITS_Educational_group.jpg" alt="Image" />
          <p className="mt-5"></p>
        </div>
        <hr className="h-px my-8 bg-gray-200 border-0 dark:bg-gray-700" />
        <div className="prose max-w-screen-lg mx-4">
          <h1 className="heading text-tw-prose-headings font-extrabold text-2xl mb-4 leading-tight border-l-4 border-red-600 pl-4 pr-4">
            About ITSEC
          </h1>
          <p className="text-justify mt-5 mb-5">
            I.T.S Engineering College, situated in Greater Noida, stands as a
            distinguished institution for Engineering and Management.
            Established by prominent professionals with a commitment to
            delivering high-quality, industry-focused education at an affordable
            cost, the college has a rich history spanning approximately three
            decades. The ITS Education Group, with its roots firmly planted in
            North India, has become a significant player in higher education.
            The group oversees nine institutes with a collective student body
            exceeding 20,000 and a dedicated staff of over 1,250.
          </p>
          <img
            src="https://www.collegebatch.com/static/clg-gallery/its-engineering-college-greater-noida-286203.jpg"
            alt=""
            className="mt-8 mb-8"
          />
          <p className="text-justify mt-5 mb-5">
            Operating with excellence in various disciplines, including
            Information Technology, Engineering, Management, Dental, Pharmacy,
            and Physiotherapy, the ITS Education Group has been a prominent
            force since its inception in 2006 under the visionary leadership of
            Chairman Dr. R.P. Chadha. ITS Engineering College boasts NBA
            accreditation, a testament to its unwavering commitment to providing
            top-notch education. The college, approved by AICTE and affiliated
            with AKTU-Lucknow, offers a diverse range of programs. These include
            B. Tech in Civil, Computer Science & Engineering (CSE), CSE with
            specializations in Artificial Intelligence and Machine Learning, and
            Data Science. Additionally, the college provides programs in
            Electronics and Communication Engineering (ECE) ,Electronics Engineering
            (VLSI Design and Technology), Electrical and Computer Engineering,
            Mechanical Engineering, and an MBA program.
           </p>
           </div>
           <hr className="h-px my-8 bg-gray-200 border-0 dark:bg-gray-700" />
           <div className="prose max-w-screen-lg mx-4">
           <h1 className="heading text-tw-prose-headings font-extrabold text-2xl mb-4 leading-tight border-l-4 border-red-600 pl-4 pr-4">
            About ECE
           </h1>
           <p className="text-justify mt-5">
           The Electronics and Communication Engineering (ECE) department in a Bachelor of Technology (B.Tech) program is dedicated to the study and application of electronic devices,
           circuits, and communication equipment.
           This field combines the principles of electrical engineering with those of computer science, making it a versatile and dynamic discipline. 
           Here’s an overview of what students can expect from an ECE department in a B.Tech program
           <br />
           <br />
           Career Opportunities
           Graduates of ECE programs have a wide range of career opportunities in various sectors, including:
           Telecommunications: Working with mobile operators, satellite communication companies, and internet service providers.
           Electronics Design and Manufacturing: Designing and manufacturing electronic components and systems.
           Information Technology: Developing hardware and software solutions for IT companies.
           Research and Development: Engaging in R&D for technological innovation in both academia and industry.
            <br />
            <br />
            ITS Engineering College is an undergraduate programme with advanced 
            learning solutions imparting knowledge of advanced innovations like
            Machine Learning, often called Deep Learning and Artificial
            Intelligence. Apart from CSE and AIML, ITSEC offers B. Tech in the
            specialization of Data Science which is a rapidly growing field that
            involves the analytical technique of extracting usable information
            from a pool of data for the benefit of businesses. Corporations
            require this valuable data for their strategic planning,
            forecasting, fraud detection, and decision-making amongst many other
            uses.
          </p>
        </div>
      </div>
    </div>
  );
};
export default About;
